package com.shiroha.mmdskin.compat.vr;

import com.shiroha.mmdskin.config.ConfigManager;
import com.shiroha.mmdskin.player.runtime.MmdSkinRendererPlayerHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * 文件职责：集中判断本地玩家 VR 手臂与自体隐藏条件。
 */
public final class VRArmHider {
    private VRArmHider() {
    }

    public static boolean isLocalPlayerInVR() {
        if (!ConfigManager.isVREnabled() || !VRDetector.isAvailable()) {
            return false;
        }

        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null) {
            return false;
        }
        return VRDataProvider.isVRPlayer(player);
    }

    public static boolean shouldHideVRArms() {
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null) {
            return false;
        }

        return minecraft.options.getCameraType().isFirstPerson()
                && isLocalPlayerInVR()
                && MmdSkinRendererPlayerHelper.isUsingMmdModel(player);
    }
}
